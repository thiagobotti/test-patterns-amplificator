using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.iOS;
using Evaluation;
using System.Xml.Linq;
using System.IO;
using System.Drawing;
using System.Reflection;

namespace UnitTestProject.BuscaFilme
{

    [TestClass]
    public class BuscaFilmeCombinedExpressionsInOrder
    {
		AppiumDriver<IWebElement> _driver = null;
		DesiredCapabilities _capabilities = new DesiredCapabilities();
        LocatorStrategy _locator = null; 

		
        [TestMethod]
        public void TestMethodMain()
        {

			/*APPIUM config*/
			_capabilities.SetCapability("platformName", ProjectConfig.PlataformName);
			_capabilities.SetCapability("platformVersion", ProjectConfig.PlatformVersion);
			_capabilities.SetCapability("deviceName", ProjectConfig.DeviceName);
			_capabilities.SetCapability("appPackage", ProjectConfig.AppPackage);
			_capabilities.SetCapability("newCommandTimeout", "3000");
			_capabilities.SetCapability("sessionOverride", "true");

			Uri defaultUri = new Uri(ProjectConfig.AppiumServer);

			if (ProjectConfig.PlataformName == "Android")
			{
			    _capabilities.SetCapability("app", ProjectConfig.AppPath);
				_capabilities.SetCapability("appActivity", ProjectConfig.AppActivity);

				_driver = new AndroidDriver<IWebElement>(defaultUri, _capabilities, TimeSpan.FromSeconds(3000));
			}
			else if (ProjectConfig.PlataformName == "iOS")
			{
                _capabilities.SetCapability("automationName", "XCUITest");
			    _capabilities.SetCapability("app", ProjectConfig.AppPath);
			    _capabilities.SetCapability("bundleId", ProjectConfig.AppPackage);
 				_capabilities.SetCapability("udid", ProjectConfig.Uuid);
				_driver = new IOSDriver<IWebElement>(defaultUri, _capabilities, TimeSpan.FromSeconds(3000));
			}

            System.Threading.Thread.Sleep(5000);



            _locator = new LocatorStrategy(_driver, null);


			 
			 /*initialing test*/
			
            if (!File.Exists(@"time.txt"))
            File.Create(@"time.txt");

            System.Threading.Thread.Sleep(15000);
            File.AppendAllText(@"time.txt","Starts on " + DateTime.Now);
            Boolean identical;
            List<Bitmap> states = new List<Bitmap>();
            List<MethodDinamic> allEvents = new List<MethodDinamic>();


            allEvents.Add(new MethodDinamic() { Name = "MenuClickSendClick_Test"});
            MenuClickSendClick_Test(); //MenuClick

            allEvents.Add(new MethodDinamic() { Name = "BuscaClickSendClick_Test"});
            BuscaClickSendClick_Test(); //BuscaClick

            allEvents.Add(new MethodDinamic() { Name = "CarTextSendKeys_Test"});
            CarTextSendKeys_Test(); //CarText

            allEvents.Add(new MethodDinamic() { Name = "ItemClickSendClick_Test"});
            ItemClickSendClick_Test(); //ItemClick

            _driver.ResetApp();
            File.AppendAllText(@"time.txt","Patterns Starts on " + DateTime.Now);

            SideDrowerMenu();

            //BackEvent(allEvents);
            File.AppendAllText(@"time.txt"," | Ends on " + DateTime.Now);


            Exec.Instance.EndSuccefull();


        }

        public void MenuClickSendClick_Test()
        {
            ForceUpdateScreen();
            string[] selectors = new string[0];

            if (ProjectConfig.PlataformName == "Android")
            {
                selectors = new string[] {@"", @"", @"", @"", @"//*[@resource-id='android:id/content']/*[1]/*[1]/*[1]/*[2]/*[1]/*[1]/*[1]/*[1]", @"hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.support.v4.widget.DrawerLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ImageButton"};
            }
            else if (ProjectConfig.PlataformName == "iOS")
            {
                selectors = new string[] {@"", @"", @"", @"", @"", @""};
            }

            string[] selectorsType = new string[] {@"IdentifyAttributes", @"ElementType", @"AncestorAttributes", @"CrossPlatform", @"AncestorIndex", @"AbsolutePath"};

            IWebElement e = _locator.FindElementByXPathInOrder(selectors, selectorsType);

            e.Click();

            /*Insert your assert here*/

        }


        public void BuscaClickSendClick_Test()
        {
            ForceUpdateScreen();
            string[] selectors = new string[0];

            if (ProjectConfig.PlataformName == "Android")
            {
                selectors = new string[] {@"", @"//*/android.widget.TextView[@text='Search']", @"//*[@resource-id='android:id/content']//*[@text='Search']", @"//*[@text='Search']", @"//*[@resource-id='android:id/content']/*[1]/*[1]/*[2]/*[2]/*[2]", @"hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.support.v4.widget.DrawerLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.TextView[2]"};
            }
            else if (ProjectConfig.PlataformName == "iOS")
            {
                selectors = new string[] {@"", @"", @"", @"//*[@text='Search']", @"", @""};
            }

            string[] selectorsType = new string[] {@"IdentifyAttributes", @"ElementType", @"AncestorAttributes", @"CrossPlatform", @"AncestorIndex", @"AbsolutePath"};

            IWebElement e = _locator.FindElementByXPathInOrder(selectors, selectorsType);

            e.Click();

            /*Insert your assert here*/

        }


        public void CarTextSendKeys_Test()
        {
            ForceUpdateScreen();
            string[] selectors = new string[0];

            if (ProjectConfig.PlataformName == "Android")
            {
                selectors = new string[] {@"", @"", @"", @"", @"//*[@resource-id='android:id/content']/*[1]/*[2]/*[2]/*[1]/*[1]/*[1]", @"hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup"};
            }
            else if (ProjectConfig.PlataformName == "iOS")
            {
                selectors = new string[] {@"", @"", @"", @"", @"", @""};
            }

            string[] selectorsType = new string[] {@"IdentifyAttributes", @"ElementType", @"AncestorAttributes", @"CrossPlatform", @"AncestorIndex", @"AbsolutePath"};

            IWebElement e = _locator.FindElementByXPathInOrder(selectors, selectorsType);

            e.Click();
            e.Clear();
            e.SendKeys("Car");
            try {
                if (ProjectConfig.PlataformName == "Android")
                    _driver.HideKeyboard();
                else if (ProjectConfig.PlataformName == "iOS")
                    _driver.FindElementByXPath("//*[@name='Hide keyboard']").Click();
            } catch {}

            /*Insert your assert here*/

        }


        public void ItemClickSendClick_Test()
        {
            ForceUpdateScreen();
            string[] selectors = new string[0];

            if (ProjectConfig.PlataformName == "Android")
            {
                selectors = new string[] {@"", @"", @"", @"", @"//*[@resource-id='android:id/content']/*[1]/*[2]/*[2]/*[1]/*[2]/*[1]/*[1]", @"hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup"};
            }
            else if (ProjectConfig.PlataformName == "iOS")
            {
                selectors = new string[] {@"", @"", @"", @"", @"", @""};
            }

            string[] selectorsType = new string[] {@"IdentifyAttributes", @"ElementType", @"AncestorAttributes", @"CrossPlatform", @"AncestorIndex", @"AbsolutePath"};

            IWebElement e = _locator.FindElementByXPathInOrder(selectors, selectorsType);

            e.Click();

            /*Insert your assert here*/

        }

        public void SideDrowerMenu()
        {
            // Declara as vari�veis
            bool haveMenu = false;
            Bitmap initialState;
            Bitmap finalState;
            System.Threading.Thread.Sleep(10000);
            Bitmap homeState = getState("homeState");

            int height = _driver.Manage().Window.Size.Height;
            int width = _driver.Manage().Window.Size.Width;

            // Salva os estados e tenta acessar o menu por swipe
            initialState = getState("initialState");
            _driver.Swipe(0, height / 2, width / 2, height / 2, 20000);
            finalState = getState("finalState");

            // Verifica se abriu um menu
            if ((bool)ExecuteMethod(new MethodDinamic() { Name = "isDifferent", Parameter = new List<object>() { initialState, finalState } }))
                haveMenu = true;
            else
            { 
                // Limpa as os estados
                initialState.Dispose();
                finalState.Dispose();

                // Tenta acessar o menu clicando no canto direito e salva o estado
                initialState = getState("initialState");
                _driver.Tap(1, 80, 80, 1000);
                finalState = getState("finalState");

                // Verifica se existe menu
                if ((bool)ExecuteMethod(new MethodDinamic() { Name = "isDifferent", Parameter = new List<object>() { initialState, finalState } }))
                    haveMenu = true;

            }

            // Se existir menu
            if (haveMenu)
            {
                try
                {

                // Limpa vari�veis
                initialState.Dispose();
                finalState.Dispose();
                
                // um click a cada 60pxs
                int qtdeClicks = height / 60;

                    // para cada click
                    for (int i = 1; i <= qtdeClicks; i++)
                    {

                        // clica em um espa�o do menu
                        initialState = getState("initialState");
                        _driver.Tap(1, 60, 60 * i, 1000);
                        finalState = getState("finalState");
                        
                        // Verifica se quando clicou no menu mudou de tela
                        if ((bool)ExecuteMethod(new MethodDinamic() { Name = "isDifferent", Parameter = new List<object>() { initialState, finalState } }))
                        {
                            // Se mudou, verifica se � a home
                            if (!(bool)ExecuteMethod(new MethodDinamic() { Name = "isDifferent", Parameter = new List<object>() { homeState, finalState } }))
                            {
                                File.AppendAllText(@"time.txt", "| Fail on access a menu item. ");
                            }
                        }

                    }

                }
                catch (Exception ex)
                {

                    File.AppendAllText(@"time.txt", "| Fail on access a menu item. " + ex.Message);
                }
            }
            else
            {
                File.AppendAllText(@"time.txt", "| Menu not exists. ");
            }


        }
         
        public void BackEvent(List<MethodDinamic> allEvents)
        {
            Bitmap initialState;
            Bitmap finalState;
            Bitmap homeState;
            System.Threading.Thread.Sleep(10000);
            homeState = getState("homeState"); 

           for (int i = 0; i < allEvents.Count; i++) 
           { 
               initialState = getState("initialState"); 
               ExecuteMethod(allEvents[i]); 
               finalState = getState("finalState"); 
               if ((bool)ExecuteMethod(new MethodDinamic() { Name = "isDifferent", Parameter = new List<object>() { initialState, finalState } })) 
               { 
                   _driver.Navigate().Back(); 
                   finalState.Dispose(); 
                   finalState = getState("finalState"); 
                   if ((bool)ExecuteMethod(new MethodDinamic() { Name = "isDifferent", Parameter = new List<object>() { initialState, finalState } })) 
                   { 
                        File.AppendAllText(@"time.txt", "| Error on event: " + allEvents[i].Name); 
                        _driver.ResetApp(); 
                        System.Threading.Thread.Sleep(5000); 
                        
                        for (int e = 0; e <= i; e++) 
                        { 
                           ExecuteMethod(allEvents[e]); 
                        } 
                   } 
                   else 
                   { 
                       ExecuteMethod(allEvents[i]); 
                   } 
               } 
                   initialState.Dispose(); 
                   finalState.Dispose(); 
           } 
       } 

         
        public object ExecuteMethod(MethodDinamic method)
        {

            Type type = typeof(BuscaFilmeCombinedExpressionsInOrder); 
            if (type != null)
            {
                MethodInfo methodInfo = type.GetMethod(method.Name);

                if (methodInfo != null)
                {
                    object result = null;
                    ParameterInfo[] parameters = methodInfo.GetParameters();
                    object classInstance = this;

                    if (parameters.Length == 0)
                    {
                        return result = methodInfo.Invoke(classInstance, null);
                    }
                    else
                    {
                        return result = methodInfo.Invoke(classInstance, method.Parameter.ToArray());

                    }
                }
            }

        return null;
        }
         
        public class MethodDinamic
        {
            public String Name;
            public List<object> Parameter;
        }
        
        public Bitmap getInitialState() 
        { 
            _driver.GetScreenshot().SaveAsFile(@"initialState.bmp",ScreenshotImageFormat.Bmp); 
           return new Bitmap(@"initialState.bmp");        }
        
        public Bitmap getFinalState() 
        { 
            _driver.GetScreenshot().SaveAsFile(@"finalState.bmp",ScreenshotImageFormat.Bmp); 
           return new Bitmap(@"finalState.bmp");       }
         
        public bool isDifferent(Bitmap initialState, Bitmap finalState)
        {
            int count = 0;
            int different = 0;

            if (!initialState.Size.Equals(finalState.Size))
            {
                return true;
            }
            for (int x = 0; x < initialState.Width; ++x)
            {
                for (int y = 0; y < initialState.Height; ++y)
                {
                    count++;
                    if (initialState.GetPixel(x, y) != finalState.GetPixel(x, y))
                    {
                        different++;
                    }
                }
            }
            if (((different * 100) / count) > 20)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        
        public Bitmap getHomeState() 
        { 
            _driver.GetScreenshot().SaveAsFile(@"homeState.bmp",ScreenshotImageFormat.Bmp); 
           return new Bitmap(@"homeState.bmp");       }
        
        public Bitmap getState(string state) 
        { 
            _driver.GetScreenshot().SaveAsFile(@"" +  state + ".bmp",ScreenshotImageFormat.Bmp); 
           return new Bitmap(@"" + state + ".bmp");       }



		private void ForceUpdateScreen()
		{
            //workaround for forces screen update 
            System.Threading.Thread.Sleep(500);
            string x = _driver.PageSource;
            System.Threading.Thread.Sleep(500);

        }


        private void ScrollToBottom()
        {
            var size = _driver.Manage().Window.Size;
            int startx = size.Width / 2;
            int starty = (int)(size.Height * 0.9);
            int endx = size.Width / 2;
            int endy = (int)(size.Height * 0.2);
            _driver.Swipe(startx, starty, startx, endy, 100);

            System.Threading.Thread.Sleep(1000);


        }

        private void Tap(int x, int y)
        {
            _driver.Tap(1, x, y, 500);

        }
    }
}
